import React, { useMemo, useState } from "react";
import {
  Activity, AlertTriangle, ArrowUpRight, BarChart3, BatteryCharging, Bell,
  Bot, Boxes, BrainCircuit, Building2, CalendarClock, CheckCircle2, ChevronRight,
  ClipboardCheck, Cpu, Database, Factory, FileCheck2, Gauge, HardHat, HeartPulse,
  Layers3, LayoutDashboard, PackageSearch, Plus, QrCode, RadioTower, Search,
  Settings, ShieldCheck, ShoppingCart, Sparkles, Thermometer, Users, Wrench,
  Zap, TrendingUp, Clock3, CircleDollarSign, MapPin, Workflow, MonitorCog
} from "lucide-react";
import { AreaChart, Area, BarChart, Bar, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, PieChart, Pie, Cell } from "recharts";

const MODULES = [
  { id: "command", label: "Command Center", icon: LayoutDashboard, group: "Dirección" },
  { id: "assets", label: "Activos y QR", icon: QrCode, group: "Operación" },
  { id: "workorders", label: "Órdenes de trabajo", icon: Wrench, group: "Operación" },
  { id: "predictive", label: "IA predictiva", icon: BrainCircuit, group: "Inteligencia" },
  { id: "digital", label: "Gemelo digital", icon: Layers3, group: "Inteligencia" },
  { id: "production", label: "Producción", icon: Factory, group: "Operación" },
  { id: "quality", label: "Calidad QMS", icon: ClipboardCheck, group: "Operación" },
  { id: "ehs", label: "Seguridad EHS", icon: HardHat, group: "Cumplimiento" },
  { id: "energy", label: "Energía", icon: Zap, group: "Sustentabilidad" },
  { id: "inventory", label: "Almacén inteligente", icon: Boxes, group: "Cadena de suministro" },
  { id: "purchases", label: "Compras IA", icon: ShoppingCart, group: "Cadena de suministro" },
  { id: "people", label: "Personal y capacitación", icon: Users, group: "Talento" },
  { id: "client", label: "Portal del cliente", icon: Building2, group: "Experiencia" },
  { id: "integrations", label: "Integraciones", icon: Workflow, group: "Plataforma" },
  { id: "saas", label: "Administración SaaS", icon: MonitorCog, group: "Plataforma" },
];

const trendData = [
  { day: "Lun", availability: 93.2, compliance: 82 }, { day: "Mar", availability: 94.8, compliance: 86 },
  { day: "Mié", availability: 96.1, compliance: 89 }, { day: "Jue", availability: 95.4, compliance: 91 },
  { day: "Vie", availability: 97.2, compliance: 94 }, { day: "Sáb", availability: 96.8, compliance: 96 },
  { day: "Hoy", availability: 98.1, compliance: 97 },
];
const workData = [
  { name: "Preventivo", value: 64 }, { name: "Correctivo", value: 18 }, { name: "Predictivo", value: 12 }, { name: "Inspección", value: 6 }
];
const COLORS = ["#111827", "#d97706", "#0f766e", "#94a3b8"];

const assetRows = [
  { asset: "Compresor Atlas Copco GA75", code: "CMP-001", plant: "Planta Querétaro", health: 92, status: "Operando", next: "18 Jul" },
  { asset: "Centro CNC Haas VF-4", code: "CNC-014", plant: "Nave 2", health: 76, status: "Atención", next: "12 Jul" },
  { asset: "Bomba PTAR P-03", code: "PTAR-003", plant: "Servicios", health: 61, status: "Riesgo", next: "Hoy" },
  { asset: "Subestación 500 kVA", code: "ELE-002", plant: "Planta Querétaro", health: 96, status: "Operando", next: "02 Ago" },
];

const alerts = [
  { level: "Crítica", title: "Vibración fuera de patrón", detail: "Bomba PTAR P-03 · Probabilidad de falla 78%", time: "Hace 8 min", icon: Activity },
  { level: "Alta", title: "Temperatura creciente", detail: "Rodamiento CNC-014 · +11.4 °C vs. línea base", time: "Hace 24 min", icon: Thermometer },
  { level: "Media", title: "Stock mínimo alcanzado", detail: "Filtro 1622-2082-00 · Existencia: 2 piezas", time: "Hace 1 h", icon: PackageSearch },
];

const moduleCopy = {
  assets: ["Jerarquía multisitio y criticidad ABC", "Expediente técnico, historial y costos de ciclo de vida", "Etiquetas QR/RFID y alta masiva", "Mapa de activos y documentación"],
  workorders: ["OT preventivas, correctivas, predictivas y de inspección", "Checklists dinámicos, evidencias, firmas y tiempos", "Planeador automático de cuadrillas y rutas", "SLA, costos, materiales y cierre técnico"],
  predictive: ["Detección de anomalías por vibración, temperatura y energía", "Índice de salud y vida útil remanente", "Recomendaciones explicables y priorizadas", "Aprendizaje por activo, planta y contexto operativo"],
  digital: ["Modelo visual de planta, líneas, sistemas y activos", "Capas de condición, riesgo, producción y energía", "Navegación desde planta hasta componente", "Simulación de impacto y escenarios de paro"],
  production: ["OEE, disponibilidad, rendimiento y calidad", "Paros, microparos y pérdidas por línea", "Andon digital y escalamiento automático", "Relación producción–mantenimiento–calidad"],
  quality: ["No conformidades, CAPA y auditorías", "Planes de inspección y control documental", "Trazabilidad por lote, producto y equipo", "KPIs ISO 9001 y análisis de recurrencia"],
  ehs: ["Incidentes, matriz de riesgos y acciones", "EPP, LOTO, ATS/AST y permisos de trabajo", "Extintores, brigadas y primeros auxilios", "Evidencia geolocalizada y KPIs STPS/ISO 45001"],
  energy: ["Consumo por planta, línea, activo y turno", "Demanda, factor de potencia y costo energético", "Alertas de desviación y fugas", "Huella de carbono y oportunidades de ahorro"],
  inventory: ["Mínimos, máximos, criticidad y reservas por OT", "Trazabilidad de refacciones y ubicaciones", "Pronóstico de consumo y riesgo de ruptura", "Conteos cíclicos, transferencias y obsolescencia"],
  purchases: ["Solicitudes y comparativos inteligentes", "Evaluación de proveedor, precio, plazo y calidad", "Órdenes de compra y recepción contra OT", "Reabasto sugerido por IA y presupuesto"],
  people: ["Matriz de habilidades y certificaciones", "Onboarding guiado por puesto", "Capacitación autónoma con IA TITÁN", "Credenciales, incidencias y productividad"],
  client: ["SLA, avance, evidencias y firmas en tiempo real", "Solicitudes, aprobaciones y comunicación", "Reportes ejecutivos y ahorro demostrado", "Marca blanca por cliente o unidad de negocio"],
  integrations: ["SAP, ERP, SCADA, OPC UA, PLC e IoT", "APIs, webhooks y conectores industriales", "Importación masiva y gobierno de datos", "Arquitectura preparada para edge y nube"],
  saas: ["Multiempresa, multisitio y segregación de datos", "Planes, licencias, consumo y facturación", "Roles, permisos, auditoría y soporte", "Panel DEYMA para implementación y éxito del cliente"],
};

function Metric({ icon: Icon, label, value, delta, foot, tone = "dark" }) {
  return <div className="titan-card titan-metric">
    <div className={`titan-icon ${tone}`}><Icon size={19}/></div>
    <div className="titan-metric-label">{label}</div>
    <div className="titan-metric-value">{value}</div>
    <div className="titan-metric-foot"><span className="positive">{delta}</span>{foot}</div>
  </div>;
}

function CommandCenter() {
  return <>
    <section className="titan-hero">
      <div>
        <div className="titan-eyebrow"><Sparkles size={14}/> Inteligencia industrial activa</div>
        <h1>CEO Command Center</h1>
        <p>Visibilidad integral de operación, mantenimiento, seguridad, energía y rentabilidad en todas las unidades.</p>
      </div>
      <div className="titan-hero-actions">
        <button className="titan-button secondary"><CalendarClock size={16}/> Últimos 7 días</button>
        <button className="titan-button primary"><Bot size={16}/> Preguntar a TITÁN IA</button>
      </div>
    </section>

    <div className="titan-metrics-grid">
      <Metric icon={Gauge} label="Disponibilidad global" value="98.1%" delta="↑ 2.4% " foot="vs. periodo anterior" />
      <Metric icon={ClipboardCheck} label="Cumplimiento PM" value="96.7%" delta="↑ 5.1% " foot="1,284 tareas cerradas" tone="teal"/>
      <Metric icon={CircleDollarSign} label="Ahorro validado" value="$1.84 M" delta="↑ $286 mil " foot="este mes" tone="amber"/>
      <Metric icon={ShieldCheck} label="Días sin accidentes" value="184" delta="Récord +31 días " foot="en 5 plantas" tone="green"/>
    </div>

    <div className="titan-grid-main">
      <div className="titan-card chart-card">
        <div className="card-head"><div><span className="card-kicker">Desempeño operativo</span><h3>Disponibilidad y cumplimiento</h3></div><span className="live-pill"><span/> EN VIVO</span></div>
        <ResponsiveContainer width="100%" height={280}>
          <AreaChart data={trendData} margin={{ top: 10, right: 8, left: -20, bottom: 0 }}>
            <defs><linearGradient id="titanFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#111827" stopOpacity={0.22}/><stop offset="100%" stopColor="#111827" stopOpacity={0}/></linearGradient></defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb"/>
            <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fontSize:11, fill:'#64748b'}}/>
            <YAxis domain={[70,100]} axisLine={false} tickLine={false} tick={{fontSize:11, fill:'#64748b'}}/>
            <Tooltip contentStyle={{borderRadius:12,border:'1px solid #e5e7eb',boxShadow:'0 12px 30px rgba(15,23,42,.12)'}}/>
            <Area type="monotone" dataKey="availability" name="Disponibilidad" stroke="#111827" strokeWidth={3} fill="url(#titanFill)"/>
            <Area type="monotone" dataKey="compliance" name="Cumplimiento" stroke="#d97706" strokeWidth={2} fill="transparent"/>
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="titan-card ai-card">
        <div className="ai-orb"><BrainCircuit size={30}/></div>
        <span className="card-kicker">TITÁN IA · Resumen ejecutivo</span>
        <h3>La operación mejoró, pero existen 3 riesgos prioritarios.</h3>
        <p>La disponibilidad aumentó por la reducción de correctivos en Línea 2. Recomiendo intervenir la bomba P-03 durante la ventana de hoy a las 18:00 para evitar un paro estimado de 7.5 horas.</p>
        <button className="text-action">Ver análisis completo <ArrowUpRight size={15}/></button>
        <div className="ai-confidence"><span>Confianza del análisis</span><strong>94%</strong><div><i style={{width:'94%'}}/></div></div>
      </div>
    </div>

    <div className="titan-grid-bottom">
      <div className="titan-card">
        <div className="card-head"><div><span className="card-kicker">Condición de activos</span><h3>Activos críticos</h3></div><button className="icon-button"><ChevronRight size={18}/></button></div>
        <div className="asset-list">{assetRows.map(a=><div className="asset-row" key={a.code}>
          <div className="asset-avatar"><Cpu size={17}/></div><div className="asset-name"><strong>{a.asset}</strong><span>{a.code} · {a.plant}</span></div>
          <div className="health"><div><i style={{width:`${a.health}%`}}/></div><strong>{a.health}%</strong></div>
          <span className={`status ${a.status.toLowerCase()}`}>{a.status}</span>
        </div>)}</div>
      </div>
      <div className="titan-card">
        <div className="card-head"><div><span className="card-kicker">Atención inmediata</span><h3>Alertas inteligentes</h3></div><span className="count-pill">3 nuevas</span></div>
        <div className="alert-list">{alerts.map((a,i)=><div className="alert-row" key={i}><div className={`alert-icon l${i}`}><a.icon size={17}/></div><div><div><span>{a.level}</span> · {a.time}</div><strong>{a.title}</strong><p>{a.detail}</p></div></div>)}</div>
      </div>
      <div className="titan-card donut-card">
        <div className="card-head"><div><span className="card-kicker">Carga de mantenimiento</span><h3>OT por tipo</h3></div></div>
        <div className="donut-wrap"><ResponsiveContainer width="58%" height={210}><PieChart><Pie data={workData} innerRadius={55} outerRadius={78} paddingAngle={3} dataKey="value">{workData.map((_,i)=><Cell key={i} fill={COLORS[i]}/>)}</Pie><Tooltip/></PieChart></ResponsiveContainer><div className="donut-center"><strong>428</strong><span>OT activas</span></div><div className="legend">{workData.map((w,i)=><div key={w.name}><i style={{background:COLORS[i]}}/><span>{w.name}</span><strong>{w.value}%</strong></div>)}</div></div>
      </div>
    </div>
  </>;
}

function ModulePage({ module }) {
  const Icon = module.icon;
  const capabilities = moduleCopy[module.id] || [];
  return <>
    <section className="titan-hero module-hero">
      <div><div className="titan-eyebrow"><Icon size={14}/> Módulo TITÁN OS</div><h1>{module.label}</h1><p>Control operativo centralizado, trazabilidad completa e inteligencia contextual diseñada para la industria.</p></div>
      <div className="titan-hero-actions"><button className="titan-button secondary"><FileCheck2 size={16}/> Exportar</button><button className="titan-button primary"><Plus size={16}/> Nuevo registro</button></div>
    </section>
    <div className="module-kpis">
      <Metric icon={Activity} label="Indicador principal" value="96.4%" delta="↑ 3.2% " foot="desempeño mensual"/>
      <Metric icon={CheckCircle2} label="Cumplimiento" value="284 / 296" delta="12 pendientes " foot="priorizados por IA" tone="teal"/>
      <Metric icon={Clock3} label="Tiempo medio" value="2 h 18 m" delta="↓ 19 min " foot="contra objetivo" tone="amber"/>
      <Metric icon={TrendingUp} label="Impacto generado" value="$428 mil" delta="↑ 14.8% " foot="ahorro estimado" tone="green"/>
    </div>
    <div className="module-content-grid">
      <div className="titan-card module-feature-card">
        <div className="feature-icon"><Icon size={28}/></div><span className="card-kicker">Capacidades incluidas</span><h2>Operación integral, no funciones aisladas</h2>
        <p>TITÁN conecta cada registro con activos, personas, costos, riesgos, documentos y decisiones para eliminar silos de información.</p>
        <div className="capability-list">{capabilities.map((c,i)=><div key={c}><span>{String(i+1).padStart(2,'0')}</span><p>{c}</p><CheckCircle2 size={18}/></div>)}</div>
      </div>
      <div className="titan-card live-panel">
        <div className="card-head"><div><span className="card-kicker">Actividad del módulo</span><h3>Panel operacional</h3></div><span className="live-pill"><span/> SINCRONIZADO</span></div>
        <ResponsiveContainer width="100%" height={220}><BarChart data={[{n:'Semana 1',v:62},{n:'Semana 2',v:74},{n:'Semana 3',v:81},{n:'Semana 4',v:96}]}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb"/><XAxis dataKey="n" axisLine={false} tickLine={false} tick={{fontSize:11}}/><YAxis axisLine={false} tickLine={false} tick={{fontSize:11}}/><Tooltip/><Bar dataKey="v" fill="#111827" radius={[6,6,0,0]}/></BarChart></ResponsiveContainer>
        <div className="mini-feed"><div><span className="feed-dot success"/><p><strong>Actualización automática completada</strong><br/>Datos consolidados de 5 instalaciones</p><small>Ahora</small></div><div><span className="feed-dot warn"/><p><strong>Revisión requerida por supervisor</strong><br/>2 registros excedieron su tolerancia</p><small>12 min</small></div><div><span className="feed-dot info"/><p><strong>TITÁN IA generó una recomendación</strong><br/>Optimización disponible para aprobación</p><small>31 min</small></div></div>
      </div>
    </div>
  </>;
}

export default function TitanOSPage(){
  const [active, setActive] = useState("command");
  const [query, setQuery] = useState("");
  const selected = MODULES.find(m=>m.id===active) || MODULES[0];
  const visible = useMemo(()=>MODULES.filter(m=>m.label.toLowerCase().includes(query.toLowerCase())),[query]);
  const groups = [...new Set(visible.map(m=>m.group))];
  return <div className="titan-shell">
    <aside className="titan-sidebar">
      <div className="titan-brand"><div className="titan-mark"><span/><i/></div><div><strong>TITÁN <small>OS</small></strong><span>Industrial Intelligence</span></div></div>
      <div className="titan-search"><Search size={15}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Buscar módulo..."/><kbd>⌘ K</kbd></div>
      <nav>{groups.map(group=><div className="titan-nav-group" key={group}><label>{group}</label>{visible.filter(m=>m.group===group).map(m=><button key={m.id} className={active===m.id?'active':''} onClick={()=>setActive(m.id)}><m.icon size={17}/><span>{m.label}</span>{m.id==='predictive'&&<em>IA</em>}</button>)}</div>)}</nav>
      <div className="system-health"><div><span><RadioTower size={15}/> Sistema conectado</span><strong>99.98%</strong></div><div className="health-line"><i/></div><small>128 sensores · 5 plantas · 0 incidencias</small></div>
    </aside>
    <main className="titan-main">
      <header className="titan-topbar"><div className="plant-selector"><div className="plant-icon"><Factory size={17}/></div><div><span>Vista corporativa</span><strong>Todas las instalaciones</strong></div><ChevronRight size={15}/></div><div className="top-actions"><button><Bell size={18}/><i>3</i></button><button><Settings size={18}/></button><div className="titan-user"><span>DM</span><div><strong>Didier Medina</strong><small>Director General</small></div></div></div></header>
      <div className="titan-content">{active==='command'?<CommandCenter/>:<ModulePage module={selected}/>}</div>
    </main>
  </div>;
}
